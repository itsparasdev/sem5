﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Diagnostics;

namespace sem5
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


            if (!IsPostBack)
            {
                List<Product> productList = GetProductsFromDatabase();
                ViewState["products"] = productList;
            }

        }


        private List<Product> GetProductsFromDatabase()
        {
            List<Product> products = new List<Product>();

            string Query = "Select * from product";
            Data data = new Data();
            DataTable dt = data.getProducts(Query);


            foreach (DataRow row in dt.Rows)
                        {
                            Product product = new Product
                            {
                                Id = Convert.ToInt32(row["Id"]),
                                Title = row["title"].ToString(),
                                Description = row["description"].ToString(),
                                Catagory = row["catagory"].ToString(),
                                Image = row["image"].ToString(),

                                Price = Convert.ToDecimal(row["price"])
                            };

                            products.Add(product);
                        }
                    
                
      

            return products;
        }
      
        






    }
}