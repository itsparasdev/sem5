﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Configuration;
using System.Data.SqlClient;


namespace sem5.handlers
{

    public class User
    {
        SqlConnection connection;

        public User() {
            connection = new SqlConnection(ConfigurationManager.AppSettings["DB"]);




        }

    public void addProduct(string Query)
        {
            SqlDataAdapter da = new SqlDataAdapter(Query,connection);
            DataTable dt = new DataTable();
            da.Fill(dt);






        }




    }
}