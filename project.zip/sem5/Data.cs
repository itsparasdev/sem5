﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Collections;

namespace sem5
{
    public class Data
    {

        SqlConnection connection;

        public  Data()
        {
            connection = new SqlConnection(ConfigurationManager.AppSettings["DB"]);
        }

        public void addProduct(string Query)
        {
            SqlDataAdapter da = new SqlDataAdapter(Query, connection);
            DataTable dt = new DataTable();
            da.Fill(dt);
        }

        public  DataTable getProducts(string Query)
        {
            SqlDataAdapter da = new SqlDataAdapter(Query, connection);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }


        public DataTable getProduct(string Query)
        {
            SqlDataAdapter da = new SqlDataAdapter(Query, connection);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }





    }
}