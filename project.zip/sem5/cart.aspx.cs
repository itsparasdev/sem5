﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace sem5
{
    public partial class cart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            List<Product> cart = Session["cart"] as List<Product>;

            if (cart != null)
            {
                decimal totalPrice = 0; 

                foreach (Product product in cart)
                {
                    totalPrice += product.Price; 
                }


               ViewState["amount"] = totalPrice;
              }


        }
    }
}