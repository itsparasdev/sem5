﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace sem5
{
    public partial class createProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            string Title = title.Value;
            string Description = description.Value;
            string Price  = price.Value;
            string Category =category.Value;
            string Image = image.Value;


            string Query = $"INSERT INTO product values('{Title}','{Description}','{Category}','{Price}','{Image}')";

            Data data = new Data();
            data.addProduct(Query);
            clearForm();

           



        }
        public void clearForm()
        {
            title.Value = string.Empty;
            description.Value = string.Empty;
            price.Value = string.Empty;
            category.Value = string.Empty;
            image.Value = string.Empty;
        }
        }
}