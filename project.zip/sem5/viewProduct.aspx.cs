﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace sem5
{
    public partial class viewProduct : System.Web.UI.Page
    {
        int Id;
        // viewProduct.aspx.cs
        protected void Page_Load(object sender, EventArgs e)
        {
               Id = Convert.ToInt32(Request.QueryString["id"]);

                  
                    Data data = new Data();
                    string query = $"select * from product where id={Id}";
                    DataTable product =data.getProduct(query);
              
                        if (product != null && product.Rows.Count > 0)
                        {
                    ViewState["image"] = product.Rows[0]["image"].ToString();
                    ViewState["id"] = product.Rows[0]["id"].ToString();

                    ViewState["name"] = product.Rows[0]["title"].ToString();
                    ViewState["description"] = product.Rows[0]["description"].ToString();
                    ViewState["catagory"] = product.Rows[0]["catagory"].ToString();
                    ViewState["price"] = product.Rows[0]["price"];
             




                


            }
        }

        protected void cartButton_Click(object sender, EventArgs e)
        {
        


            Data data = new Data();
            string query = $"select * from product where id={Id}";
            DataTable product = data.getProduct(query);

            if (product != null && product.Rows.Count > 0)
            {

                Product selectedProduct = new Product
                {
                    Id = Convert.ToInt32(product.Rows[0]["id"]),
                    Image = product.Rows[0]["image"].ToString(),
                    Title = product.Rows[0]["title"].ToString(),
                    Price = Convert.ToDecimal(product.Rows[0]["price"]),
                   Description =product.Rows[0]["description"].ToString(),
                    Catagory = product.Rows[0]["catagory"].ToString(),

                };


                List<Product> cart = Session["cart"] as List<Product>;
                if (cart == null)
                {
                    cart = new List<Product>();
                }

                // Add the selected product to the cart
                cart.Add(selectedProduct);

                // Update the session variable
                Session["cart"] = cart;


                Response.Redirect("/cart.aspx");


            } else
            {
         //       Response.Redirect("/index.aspx");
            }






        }
    }
}