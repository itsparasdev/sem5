
## product table
```
CREATE TABLE [dbo].[product]
(
	[Id] INT NOT NULL PRIMARY KEY, 
        [title] VARCHAR(50) NULL,
	[description] VARCHAR(50) NULL,
	[catagory] VARCHAR(50) NULL,
	[price] VARCHAR(50) NULL,
	[image] VARCHAR(50) NULL
)

```
